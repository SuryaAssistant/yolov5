
rambulalin - v1 2021-04-09 10:01am
==============================

This dataset was exported via roboflow.ai on April 9, 2021 at 3:01 AM GMT

It includes 167 images.
Trafficsign are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


